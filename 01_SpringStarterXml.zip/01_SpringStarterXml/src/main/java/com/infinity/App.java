package com.infinity;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infinity.model.Greeting;

public class App 
{
    public static void main( String[] args )
    {
    	BeanFactory factory = new ClassPathXmlApplicationContext("spring-config.xml");
    	Greeting greeting = factory.getBean("greeting", Greeting.class);
    	String message = greeting.sayHello();
    	System.out.println(message);
    }
}
