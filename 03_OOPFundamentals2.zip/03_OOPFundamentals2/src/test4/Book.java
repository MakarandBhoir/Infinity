package test4;

public class Book {
	// instance variables
	private String bookName;
	private String bookAuthor;
	private double bookPrice;
	
	// class variable
	private static double bookDiscount;
	
	// default constructor
	public Book(){
		System.out.println("constructor called.");
	}
	
	// parameterized constructor
	public Book(String bookName, String bookAuthor, double bookPrice){
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
	}
	
	public static void setBookDiscount(double bookDiscount) {
		Book.bookDiscount = bookDiscount;
	}
	
	private double calculateDiscountedPrice() {
		double bookPrice = 0.0;
		double price = this.bookPrice - ((bookDiscount / 100) * this.bookPrice);
		return price;
	}
	
	// access_specifier return_type method_name(data_type arg1, data_type arg2...) 
	public void display() {
		System.out.println("Book Name = " + bookName);
		System.out.println("Book Author = "+ this.bookAuthor);
		System.out.println("Book Price = "+ this.bookPrice);
		System.out.println("Book Discount = " + bookDiscount);
		System.out.println("Book Discounted Price = " + calculateDiscountedPrice());
		System.out.println("---------------------------------------");
	}
	
}
