package test4;

public class BookApp {
	public static void main(String[] args) {
		Book.setBookDiscount(10);
		//Book book = new Book(); // call default constructor
		Book book1 = new Book("C", "R S Kanetkar", 280.50); // call parameterized constructor
		Book book2 = new Book("Java", "Kay Horstman", 1100.50); // call parameterized constructor
		
		book1.display();
		book2.display();		
	}
}
