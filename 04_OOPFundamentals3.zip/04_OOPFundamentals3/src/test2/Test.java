package test2;

import java.lang.Object;

class A extends Object{
	protected int a = 10;
}

class B extends A{ // In this case A will be super/parent/base class
				  // B class will be sub/child/derived class
	private int b = 10;
	
	public void add() {
		int sum = a + b; //
		System.out.println("Result = "+sum);
	}
}

public class Test {
	public static void main(String[] args) {
		B obj = new B();
		obj.add();
	}
}
