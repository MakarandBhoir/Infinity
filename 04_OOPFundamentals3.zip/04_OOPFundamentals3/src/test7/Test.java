package test7;

class A{
	public void show() {
		System.out.println("show method of A");
	}
	protected void show2() {
		System.out.println("show method of A");
	}
	void show3() {
		System.out.println("show method of A");
	}
	private void show4() {
		System.out.println("show method of A");
	}
}
class B extends A{
	@Override
	public void show() {
		System.out.println("show method of B");
	}
	@Override
	public void show2() {
		System.out.println("show method of B");
	}
	@Override
	void show3() {
		System.out.println("show method of B");
	}
//	@Override
//	private void show4() {
//		System.out.println("show method of B");
//	}
}

public class Test {
	public static void main(String[] args) {
		A ref = null;
		
		ref = new A();
		ref.show(); // invoke method of A
		
		ref = new B();
		ref.show(); // invoke method of B
	}
}
