package test8;

class A{
	public void show() {
		System.out.println("show method of A");
	}
}
class B extends A{
	public void show() {
		System.out.println("show method of B");
	}
}


public class Test {
	public static void main(String[] args) {
		A ref = null;
		
		A obj1 = new A();
		B obj2 = new B();
		
		if(Math.random() > 0.5) {
			ref = obj1;
		}else {
			ref = obj2;
		}
		
		ref.show();
	}
}
