package com.infinity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infinity.config.AppConfig;
import com.infinity.model.Greeting;
import com.infinity.model.Student;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        Greeting greeting = context.getBean("greet", Greeting.class);
        System.out.println(greeting.greet("Makarand"));
        
        Student student = context.getBean("student", Student.class);
        System.out.println(student);
        System.out.println(student.getDepartment());
    }
}
