package com.infinity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.infinity.model.Student;
import com.infinity.service.StudentService;

@SpringBootApplication
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = SpringApplication.run(App.class, args);
        
        StudentService service = context.getBean(StudentService.class);
        
        Student student = context.getBean(Student.class);
        student.setStudentId(101);
        student.setStudentName("Test101");
        student.setStudentScore(99);
        student.getDepartment().setDeptId(10);
        student.getDepartment().setDeptName("EC");
        
        boolean result = service.addStudent(student);
        if(result)
        	System.out.println("Student data added successfully.");
        else
        	System.out.println("There is problem adding student.");
        
        Student result2 = service.findStudentById(student.getStudentId());
        System.out.println("Student Id = "+result2.getStudentId());
        System.out.println("Student Name = "+result2.getStudentName());
        System.out.println("Student Score = "+result2.getStudentScore());
    }
}

