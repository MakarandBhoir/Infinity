package com.infinity;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.infinity.model.Student;
import com.infinity.service.StudentService;

@SpringBootApplication
public class App2 
{
    public static void main( String[] args )
    {
        ApplicationContext context = SpringApplication.run(App2.class, args);
        StudentService service = context.getBean(StudentService.class);
                
        List<Student> list = service.findAllStudents();
        for(Student student : list) {
        	System.out.println("Student Id = "+student.getStudentId());
        	System.out.println("Student Name = "+student.getStudentName());
        	System.out.println("Student Score = "+student.getStudentScore());
        	System.out.println("-----------------------------------");
        }
    }
}

