package com.infinity.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.infinity.model.Student;

@Repository
public class StudentRepositoryImpl implements StudentRepository {
	@Autowired
	private JdbcTemplate template;

	@Override
	public boolean createStudent(Student student) {
		String query = "Insert Into Student(Student_Id, Student_Name, Student_Score) Values(?, ?, ?)";
		int result = template.update(query, student.getStudentId(), student.getStudentName(),
				student.getStudentScore());
		return result == 1 ? true : false;
	}

	// RowMapper
	@Override
	public Student readStudentById(int studentId) {
		String query = "Select * From Student Where Student_Id = " + studentId;
		//Student student = template.queryForObject(query, new StudentRowMapper());
		Student student = template.queryForObject(query, (rs, no)->{
			Student stu = new Student();
			stu.setStudentId(rs.getInt("Student_Id"));
			stu.setStudentName(rs.getString("Student_Name"));
			stu.setStudentScore(rs.getDouble("Student_Score"));
			return stu;
		} );
		return student;
	}

	@Override
	public boolean deleteStudentById(int studentId) {
		String query = "Delete From Student Where Student_Id = ?";
		int result = template.update(query, studentId);
		return result == 1 ? true : false;
	}

	@Override
	public boolean updateStudent(Student student) {
		String query = "Update Student Set Student_Name = ?, Student_Score = ? Where Student_Id = ?";
		int result = template.update(query, student.getStudentName(), student.getStudentScore(),student.getStudentId());
		return result == 1 ? true : false;
	}

	@Override
	public List<Student> readAllStudents() {
		String query = "Select * From Student";
		return template.query(query, new StudentRowMapper());
	}

}
