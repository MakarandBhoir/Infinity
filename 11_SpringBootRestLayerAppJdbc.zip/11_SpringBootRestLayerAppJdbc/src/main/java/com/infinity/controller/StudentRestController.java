package com.infinity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinity.model.Student;
import com.infinity.service.StudentService;

@RestController
@RequestMapping(path="students")
public class StudentRestController {
	@Autowired
	private StudentService service;
	
	// http://localhost:9090/students
	@GetMapping
	public List<Student> findAllStudents() {
		return service.findAllStudents();
	}
	// http://localhost:9090/students/100
	@GetMapping(path="{studentId}")
	public Student findStudentById(@PathVariable("studentId") int studentId) {
		return service.findStudentById(studentId);
	}
	// http://localhost:9090/students
	@PostMapping
	public String addStudent(@RequestBody Student student) {
		boolean result = service.addStudent(student);
		if(result) {
			return "Student is added.";
		}else {
			return "Student is not added.";
		}
	}
	// http://localhost:9090/students/100
	@DeleteMapping(path="{studentId}")
	public String deleteById(@PathVariable("studentId") int studentId) {
		boolean result = service.deleteById(studentId);
		if(result) {
			return "Student is deleted.";
		}else {
			return "Student is not deleted.";
		}
	}
}
