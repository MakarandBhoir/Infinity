package com.infinity;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infinity.model.Greeting;

public class App2 
{
    public static void main( String[] args )
    {
    	BeanFactory factory = new ClassPathXmlApplicationContext("spring-config.xml");
    	Greeting greeting1 = factory.getBean("greeting", Greeting.class);
    	Greeting greeting2 = (Greeting) factory.getBean("greeting");
    	
    	System.out.println(greeting1.hashCode());
    	System.out.println(greeting2.hashCode());
    	
    	System.out.println("---------------------------------");
    	
    	Greeting greeting3 = factory.getBean("greeting2", Greeting.class);
    	Greeting greeting4 = (Greeting) factory.getBean("greeting2");
    	
    	System.out.println(greeting3.hashCode());
    	System.out.println(greeting4.hashCode());
    }
}
