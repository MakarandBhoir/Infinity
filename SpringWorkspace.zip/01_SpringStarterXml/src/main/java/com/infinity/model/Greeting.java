package com.infinity.model;

public class Greeting {
	public String sayHello() {
		return "Hello From Spring Framework!!!";
	}
}
