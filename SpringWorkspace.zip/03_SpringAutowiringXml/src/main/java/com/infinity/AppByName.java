package com.infinity;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infinity.model.Student;

public class AppByName 
{
    public static void main( String[] args )
    {
    	BeanFactory factory = new ClassPathXmlApplicationContext("spring-config-byName.xml");
    	Student student = factory.getBean("student", Student.class);
    	System.out.println("Student Name = "+student.getStudentName());
    	System.out.println("Department object = "+student.getDepartment());
    	System.out.println("Department Name = "+student.getDepartment().getDeptName());
    }
}
