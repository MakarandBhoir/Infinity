package com.infinity.model;

public class Greeting {
	public String greet(String name) {
		return "Welcome "+name+" to Spring!!!";
	}
}
