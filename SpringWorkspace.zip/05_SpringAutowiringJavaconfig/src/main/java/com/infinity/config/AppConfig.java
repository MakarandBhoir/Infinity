package com.infinity.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.infinity.model.Department;
import com.infinity.model.Greeting;

@Configuration
@ComponentScan("com.infinity")
public class AppConfig {
	@Bean(name="greet")
	@Scope(scopeName="prototype")
	public Greeting getGreetingBean() {
		Greeting greeting = new Greeting();
		return greeting;
	}
	
	@Bean(name="dept2")
	@Scope(scopeName="prototype")
	public Department getDeptBean() {
		Department dept = new Department(1, "dummy");
		return dept;
	}
}
