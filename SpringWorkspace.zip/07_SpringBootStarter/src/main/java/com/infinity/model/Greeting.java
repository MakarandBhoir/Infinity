package com.infinity.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
public class Greeting {
	public String welcome() {
		return "Welcome to Spring Boot!";
	}
}
