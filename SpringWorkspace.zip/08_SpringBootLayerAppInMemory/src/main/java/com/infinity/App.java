package com.infinity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.infinity.model.Student;
import com.infinity.service.StudentService;

@SpringBootApplication
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = SpringApplication.run(App.class, args);
        
        StudentService service = context.getBean(StudentService.class);
        
        Student student = context.getBean(Student.class);
        student.setStudentId(100);
        student.setStudentName("Test100");
        student.setStudentScore(100);
        student.getDepartment().setDeptId(10);
        student.getDepartment().setDeptName("EC");
        
        service.addStudent(student);
        Student result = service.findStudentById(100);
        
        System.out.println(result);
        if(result != null)
        	System.out.println(result.getDepartment());
    }
}
