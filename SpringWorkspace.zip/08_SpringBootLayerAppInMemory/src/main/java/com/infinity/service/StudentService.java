package com.infinity.service;

import java.util.List;

import com.infinity.model.Student;

public interface StudentService {
	public boolean addStudent(Student student);
	public Student findStudentById(int studentId);
	public List<Student> findAllStudents();
	public List<Student> findStudentsByName(String name);
	public List<Student> findStudentsByScore(double min, double max);
	public boolean deleteById(int studentId);
	
}
