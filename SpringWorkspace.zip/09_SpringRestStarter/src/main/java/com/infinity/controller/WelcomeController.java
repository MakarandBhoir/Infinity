package com.infinity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinity.model.Student;

@RestController
public class WelcomeController {
	@Autowired
	private Student student;

	// http://localhost:8080/welcome
	@GetMapping(path = "welcome")
	public String welcome() {
		return "Welcome To Spring Rest!";
	}

	// http://localhost:8080/welcome2
	@GetMapping(path = "welcome2")
	public String welcome2() {
		return "Welcome To Spring Rest!";
	}
	
	@GetMapping(path="welcome3")
	public Student welcome3() {
		student.setFirstName("Makarand");
		student.setLastName("Bhoir");
		return student;
	}

}