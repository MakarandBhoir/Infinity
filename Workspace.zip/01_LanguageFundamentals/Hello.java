class HelloWorld
{
	public static void main(String args[])
	{
		System.out.println("\"Hello World\"");
	}
}

class A{
	public static void main(String args[])
	{
		System.out.println("Hello World from A");
	}	
	void show(){
		System.out.println("show method of A");
	}
}