public class Welcome
{
	public static void main(String makarand[])
	{
		System.out.println("Welcome To Java Programming!");
	}
}



