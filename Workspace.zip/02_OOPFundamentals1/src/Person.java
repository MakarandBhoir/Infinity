
public class Person {
	// instance variables
	String firstName;
	String lastName;
	int age;
	
	public static void main(String args[]) {
		//local variable
		int x;
		
		Person nivedita = new Person();
		Person vinit = new Person(); // instantiate class
		
		nivedita.firstName = "Nivedita";
		nivedita.lastName = "Unknown";
		nivedita.age = 19; // initilize variable
		
		vinit.firstName = "Vinit";
		vinit.lastName = "Salvi";
		vinit.age = 20;
		
		System.out.println("First Name: "+nivedita.firstName);
		System.out.println("Last Name: "+nivedita.lastName);
		System.out.println("Age: "+nivedita.age);
		
		System.out.println("---------------------------------");
		
		System.out.println("First Name: "+vinit.firstName);
		System.out.println("Last Name: "+vinit.lastName);
		System.out.println("Age: "+vinit.age);
		
	}
}
