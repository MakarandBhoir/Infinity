
public class SumOfDigits {
	
	// acc_specifier return_type name_of_method(data_type arg_1, data_type arg_2)
	public void sum(int number) {
		int s = 0; // local variable
		while(number > 0) {
			int rem = number % 10;
			s = s + rem;
			number = number / 10;
		}
		System.out.println("Sum = "+s);
	}
	
	public static void main(String[] args) {
		SumOfDigits obj = new SumOfDigits();
		obj.sum(3456);
	}
}
