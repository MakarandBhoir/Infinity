package test1;

public class Book {
	// instance variables
	private String bookName;
	private String bookAuthor;
	private double bookPrice;
	
	// access_specifier return_type method_name(data_type arg1, data_type arg2...) 
	public void display() {
		System.out.println("Book Name = " + bookName);
		System.out.println("Book Author = "+bookAuthor);
		System.out.println("Book Price = "+bookPrice);
		System.out.println("---------------------------------------");
	}
	
	public static void main(String[] args) {
		Book book1 = new Book();
		Book book2 = new Book();
		
		book1.bookName = "C";
		book1.bookAuthor = "R S Kanetkar";
		book1.bookPrice = 280.50;
		
		book1.display();
		book2.display();
	}

}
