package test2;

public class BookApp {
	public static void main(String[] args) {
		Book book1 = new Book();
		Book book2 = new Book();
		
		book1.getData("C", "R S Kanetkar", 280.50);
		book2.getData("Java", "Kay Horstman", 1100.50);
		
		book1.display();
		book2.display();
		
	}
}
