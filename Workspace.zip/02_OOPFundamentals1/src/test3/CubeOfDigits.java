package test3;

public class CubeOfDigits {
	
	public static int cube(int number) {
		int sum = 0;
		while(number > 0) {
			int rem = number % 10;
			sum = sum + (rem * rem * rem);
			number = number / 10;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		int result = CubeOfDigits.cube(1234);
		System.out.println("Result = "+result);
	}

}
