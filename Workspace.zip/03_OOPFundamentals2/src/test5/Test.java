package test5;



public class Test {
	int a, b; // instance variable
	static int c; // class variable
	
	// static & not static data member are accessible
	void meth1() {
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		System.out.println("c = "+c);
	}
	
	// cant access not static data member (variables)
	static void meth2() {
		//System.out.println("a = "+a);
		//System.out.println("b = "+b);
		System.out.println("c = "+c);
	}
	
	public static void main(String[] args) {
		int d = 0; // local variable
		
		//System.out.println("a = "+a);
		//System.out.println("b = "+b);
		System.out.println("c = "+c);
		System.out.println("d = "+d);
	}
}
