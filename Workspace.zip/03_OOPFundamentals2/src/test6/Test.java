package test6;

class Person{
	String firstName, lastName;
	
	Person(String firstName, String lastName){
		this.firstName = firstName;
		this.lastName = lastName;
	}
}

public class Test {
	
	static void display(int value) {
		value = 100;
	}
	
	static void display(Person ref) {
		ref.firstName = "Test";
		ref.lastName = "Test";
	}
	
	public static void main(String[] args) {
		int value = 200;
		Test.display(value); // calling display method by passing int value as parameter
		System.out.println("value = "+value);
		
		System.out.println("---------------------------------------");
		
		Person sourav = new Person("Sourav", "Patil");
		Test.display(sourav); // calling display method by passing ref as paramter
		
		
		System.out.println(sourav.firstName + ", "+sourav.lastName);
		
	}
}
