package test0;

class Main {
	public static void main(String args[]) {
		Main obj = new Main();
		System.out.println( obj.fun() );
	}
	
	// access_specifier return_type method_name()
	int fun() {
		return 20;
	}
}

class Main2 {
	public static void main(String args[]) {
		System.out.println( fun() );
	}
	
	// access_specifier return_type method_name()
	static int fun() {
		return 20;
	}
}
