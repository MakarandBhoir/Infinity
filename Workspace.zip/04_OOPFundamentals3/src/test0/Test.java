package test0;

class A{
	static int a = 10;
	static {
		System.out.println("static block of A");
	}
}

public class Test {
	int x = 2;
	
	static {
		System.out.println("static block of Test");
	}

	Test(int i) {
		x = i;
	}

	public static void main(String[] args) {
		System.out.println("main method called..");
		System.out.println("a = "+A.a);
	}
}