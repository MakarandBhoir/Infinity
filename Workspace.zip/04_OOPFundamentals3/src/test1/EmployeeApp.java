package test1;

public class EmployeeApp {

	public static void main(String[] args) {
		Employee vaibhavi = new Employee();
		//vaibhavi.employeeId = 100; 
		vaibhavi.setEmployeeId(100);
		vaibhavi.setEmployeeName("Vaibhavi");
		vaibhavi.setEmployeeSalary(30000);
		
		
		//System.out.println("Id = "+vaibhavi.employeeId);
		System.out.println("Id = "+vaibhavi.getEmployeeId());
		System.out.println("Name = "+vaibhavi.getEmployeeName());
		System.out.println("Salary = "+vaibhavi.getEmployeeSalary());
		
	}

}
