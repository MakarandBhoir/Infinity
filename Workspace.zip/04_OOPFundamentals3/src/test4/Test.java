package test4;

class A{
	A(){
		System.out.println("A()");
	}
}

class B extends A{
	B(){
		System.out.println("B()");
	}
}

public class Test {
	public static void main(String[] args) {
		//A obj1 = new A();
		B obj2 = new B();
	}
}
