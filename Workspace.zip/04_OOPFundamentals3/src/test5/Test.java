package test5;

class A{
	A(){
		System.out.println("A()");
	}
	A(int a){
		System.out.println("A(int a)");
	}
}

class B extends A{
	B(){
		super(10);
		System.out.println("B()");
	}
	B(int b){
		System.out.println("B(int b)");
	}
}

public class Test {
	public static void main(String[] args) {
		B obj1 = new B();
		B obj2 = new B(1000);
	}
}
