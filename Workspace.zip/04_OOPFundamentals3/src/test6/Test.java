package test6;

public class Test {

	public void meth1() {
		
	}
	
	public void meth1(int x) {
		
	}
	
	public void meth2(int x) {
		
	}
	
	public void meth2(double x) {
		
	}
	
	
//	public void meth3(int x, int y) {
//		
//	}
//	int meth3(int a, int b) {
//		return 0;
//	}

	
	public static void main(String[] args) {

	}
}
