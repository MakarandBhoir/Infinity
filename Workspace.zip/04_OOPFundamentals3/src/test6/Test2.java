package test6;

class Shape{
	public void area(int radius) {
		System.out.println("Area of circle = " + (3.14 * radius * radius) );
	}
	
	public void area(int l, int b) {
		System.out.println("Area of rectangle = " + (l * b) );
	}
}

public class Test2 {

	public static void main(String[] args) {
		Shape obj = new Shape();
		obj.area(10, 7);
		obj.area(5);
	}

}
