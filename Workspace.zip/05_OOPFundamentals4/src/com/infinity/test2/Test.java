package com.infinity.test2;

class A{
	public final void show() {
		
	}
}

final class B extends A{
// you will get compilation error
	
//	@Override
//	public void show() {
//		
//	}
}

//you will get compilation error
//class C extends B{
//	
//}

public class Test {

	public static void main(String[] args) {
		final int x = 100;
		
		// you will get compilation error
		//x = 200;
	}

}
