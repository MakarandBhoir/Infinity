package com.infinity.test3;

class Demo{
	int x;
	Demo(int x){
		System.out.println("constructor called..");
		this.x = x;
	}
	
	@Override
	public void finalize() {
		System.out.println("Clean up work..");
	}
}


public class Test {
	public static void main(String[] args) {
		Demo obj1 = new Demo(100);
		Demo obj2 = new Demo(200);
		
		obj1 = null;
		obj2 = null;
		
		System.gc();
	}
}
