package com.infinity.test4;

interface I1{
	void meth1();
	public abstract void meth2();
}

class C1 implements I1 {
	public void meth1() {
		System.out.println("meth1");
	}
	public void meth2() {
		System.out.println("meth2");
	}
}

class C2 {
	
}

public class Test {
	public static void main(String[] args) {
		//I1 obj = new I1();
		I1 obj;
		obj = new C1();
		
		obj.meth1();
		obj.meth2();
	}
}
