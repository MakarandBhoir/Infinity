package com.infinity.test6;

interface I1{
	void meth1();
}
interface I2{
	void meth2();
}

interface I3 extends I1, I2{
	void meth3();
}

class C1 implements I3{
	public void meth1() {
		System.out.println("meth1");
	}
	public void meth2() {
		System.out.println("meth2");
	}
	public void meth3() {
		System.out.println("meth3");
	}
	
}

public class Test {

	public static void main(String[] args) {
		I3 ref = new C1();
		
		ref.meth1();
		ref.meth2();
		ref.meth3();
	}

}
