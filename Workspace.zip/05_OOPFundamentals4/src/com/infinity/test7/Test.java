package com.infinity.test7;

// bank customer should have a account

class Account{
	int accountNumber;
	
	@Override
	public String toString() {
		return "account Number = "+accountNumber;
	}
}

class Customer extends Object{
	String customerName;
	Account account = new Account(); // customer has-a account
	
	@Override
	public String toString() {
		return "Name = "+customerName+", Account [ "+account +" ]";
	}
}

public class Test {
	public static void main(String[] args) {
		Customer customer = new Customer();
		customer.customerName = "Makarand";
		customer.account.accountNumber = 100001;
		
		System.out.println(customer);
	}
}
