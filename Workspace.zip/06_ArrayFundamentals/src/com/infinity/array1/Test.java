package com.infinity.array1;

public class Test {
	public static void main(String[] args) {
		int arr [] = {101, 102, 204, 304, 12, 15};
		
		System.out.println(arr[0]);
		System.out.println(arr[5]);
		
		//System.out.println(arr[6]);
		
		System.out.println("End of application");
	}
}
