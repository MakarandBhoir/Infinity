package com.infinity.array2;

public class Main {
	public static void main(String[] args) {
		Student student1 = new Student(1001, "Vinit", "9876543210", "Java", 10000);
		Student student2 = new Student(1002, "Sneha", "9876543245", "Python", 12000);
		Student student3 = new Student(1001, "Yashraj", "9876543265", "C", 7000);
		Student student4 = new Student(1001, "Vaibhavi", "9876543289", "C++", 7000);
		Student student5 = new Student(1001, "Shubham", "9876543211", "Java", 10000);
		
		//data_type arr_name[] = new data_type[size]
		Student students[] = new Student[5];
		students[0] = student1;
		students[1] = student2;
		students[2] = student3;
		students[3] = student4;
		students[4] = student5;
		
		StudentService.displayStudentByCourse(students, "C++");
		double totalFees = StudentService.getTotalFees(students);
		System.out.println("Total Fees = "+totalFees);
	}
}
