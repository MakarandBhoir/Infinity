package com.infinity.array2;

public class Student {
	private int studentId;
	private String studentName;
	private String contactNo;
	private String course;
	private double fees;
	
	public Student() {
		
	}
	public Student(int id, String name, String phone, String course, double fees) {
		studentId = id;
		studentName = name;
		contactNo = phone;
		this.course = course;
		this.fees = fees;
	}
	public void display() {
		System.out.println("Student Id = "+studentId);
		System.out.println("Student Name = "+studentName);
		System.out.println("Contact No = "+contactNo);
		System.out.println("Course = "+course);
		System.out.println("Course Fees = "+fees);
	}
	
	public int getStudentId() {
		return studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public String getCourse() {
		return course;
	}
	public double getFees() {
		return fees;
	}
}
