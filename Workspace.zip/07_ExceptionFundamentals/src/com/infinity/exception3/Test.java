package com.infinity.exception3;

class InvalidStudentNameException extends Exception{
	public InvalidStudentNameException(String message) {
		super(message);
	}
}

public class Test {
	public static void checkName(String name) throws InvalidStudentNameException {
		if(name.matches("[A-Za-z]+")) {
			System.out.println("Valid Name = "+name);
		}
		else {
			InvalidStudentNameException ex = new InvalidStudentNameException("Invalid Name = "+name);
			throw ex;
		}
	}
	
	public static void main(String[] args) {
		String studentName = "Vinit23$";
		try {
			Test.checkName(studentName);
		}
		catch(InvalidStudentNameException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("End of program..");
	}
}
