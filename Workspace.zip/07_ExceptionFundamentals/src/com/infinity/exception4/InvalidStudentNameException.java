package com.infinity.exception4;
public class InvalidStudentNameException extends RuntimeException{
	public InvalidStudentNameException(String message) {
		super(message);
	}
}