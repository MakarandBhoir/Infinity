package com.infinity.exception4;

public class Test {
	public static void checkName(String name) {
		if(name.matches("[A-Za-z]+")) {
			System.out.println("Valid Name = "+name);
		}
		else {
			InvalidStudentNameException ex = new InvalidStudentNameException("Invalid Name = "+name);
			throw ex;
		}
	}
	
	public static void main(String[] args) {
		String studentName = "Vinit";
		try {
			Test.checkName(studentName);
		}
		catch(InvalidStudentNameException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("End of program..");
	}
}
