package test;

public class StringDemo8 {

	public static void main(String[] args) {
		String str = "Hello World!";
		
		// Whether string contains only alphabets - 
		// string contains full name  - Makarand Bhoir - valid / MakarandBhoir - invalid / Makarand - invalid
		// string contains valid mobile number - 9821225699 - valid / 8775543 - invalid / 987654321q - invalid
		// string contains valid email - makarand@gmail.com - valid / makarand - invalid / makarand@.com - invalid
		
	}

}
