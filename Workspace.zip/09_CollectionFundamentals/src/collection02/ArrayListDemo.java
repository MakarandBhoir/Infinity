package collection02;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		String str1 = new String("First");
		String str2 = "Second";
		Integer iObj = new Integer(100);
		Double dObj = new Double(10.50);
		int x = 10;
		
		list.add(str1);
		list.add(str2);
		list.add(iObj);
		list.add(dObj);
		list.add(x);


		for(Object element : list) {
			if(element instanceof String) {
				String str = (String) element; //ClassCastException
				int len = str.length();
				
				System.out.println(len);
			}
		}
		
	}
}
