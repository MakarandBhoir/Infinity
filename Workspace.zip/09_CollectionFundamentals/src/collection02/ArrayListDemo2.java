package collection02;

import java.util.ArrayList;

public class ArrayListDemo2 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		//ArrayList<Object> list = new ArrayList<Object>();
		String str1 = new String("First");
		String str2 = "Second";
		
		list.add(str1);
		list.add(str2);
		list.add("ABCd");
		//list.add(100);

		for(Object element : list) {
			String str = (String) element; //ClassCastException or Type Safety problem
			int len = str.length();
			
			System.out.println(len);
		}
		
	}
}
