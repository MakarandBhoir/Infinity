package collection05;

public class Test {
	static String str = null;
	public static void main(String[] args) {
		if(str != null) {
			int len = str.length();
			System.out.println(len);
		}
	}
}
