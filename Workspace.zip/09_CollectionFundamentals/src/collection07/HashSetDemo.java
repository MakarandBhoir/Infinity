package collection07;

import java.util.HashSet;

public class HashSetDemo {
	public static void main(String[] args) {
		HashSet<String> set = new HashSet<String>();
		
		set.add("Makarand");
		set.add("Sachin");
		set.add("Virat");
		set.add("Mahendra");
		
		System.out.println(set);
		
		set.add("Makarand");
		
		System.out.println(set);
		
	}
}
