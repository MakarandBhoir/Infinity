package com.infinity.dao;

import java.util.ArrayList;

import com.infinity.model.Student;

public class StudentDao {
	static ArrayList<Student> database = new ArrayList<>();
	
	public boolean createStudent(Student student) {
		boolean result = database.add(student);
		return result;
	}
	public ArrayList<Student> readAllStudent() {
		return database;
	}
	
//	public void updateStudent() {
//		
//	}
//	public void deleteStudent() {
//		
//	}
}

// CRUD (Create, Read, Update, Delete)
	