package com.infinity.presentation;

import java.util.ArrayList;
import java.util.Scanner;

import com.infinity.dao.StudentDao;
import com.infinity.model.Student;

public class StudentManagementApp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Id: ");
		int id = sc.nextInt();
		System.out.println("Enter Student Name: ");
		String name = sc.next();
		System.out.println("Enter Student Score: ");
		double score = sc.nextDouble();
		
		Student student = new Student(id, name, score);
		Student student2 = new Student(102, "Test", 40);
		
		StudentDao dao = new StudentDao();
		dao.createStudent(student);
		dao.createStudent(student2);
		
		//Student res = dao.readStudent(102);
		
		ArrayList<Student> students = dao.readAllStudent();
		for(Student stu : students) {
			System.out.println(stu);
		}
	}
}
