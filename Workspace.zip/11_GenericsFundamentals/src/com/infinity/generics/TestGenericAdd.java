package com.infinity.generics;

public class TestGenericAdd {
	public <T> void add(T arg1, T arg2) 
	{
		if(arg1 instanceof Integer && arg2 instanceof Integer) 
		{
			int num1 = ((Integer) arg1).intValue();
			int num2 = ((Integer) arg2).intValue();
			System.out.println("Addition of two int = "+ (num1+num2));
		}
		else if(arg1 instanceof Double && arg2 instanceof Double) 
		{
			double num1 = ((Double) arg1).doubleValue();
			double num2 = ((Double) arg2).doubleValue();
			System.out.println("Addition of two double = "+ (num1+num2));
		}
	}
	public static void main(String[] args) {
		TestGenericAdd obj = new TestGenericAdd();
		obj.add(100, 200);
		obj.add(10.5, 11.5);
	}
}
