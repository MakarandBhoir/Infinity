package com.infinity.generics;

class Test<T>{
	private T obj;
	public Test(T obj) {
		this.obj = obj;
	}
	public void print() {
		System.out.println(obj);
	}
}


public class TestGenericClass {
	public static void main(String[] args) {
		Test<String> t1 = new Test<>("Infinity");
		t1.print();
		
		Test<Integer> t2 = new Test<>(100);
		t2.print();
		
		//ArrayList<String> list = new ArrayList<>();
	}
}
