package com.infinity.generics;

class Test2<T1, T2>{
	T1 key;
	T2 value;
	
	public void put(T1 key, T2 value) {
		System.out.println("Key = "+key);
		System.out.println("Value = "+value);
	}
}

public class TestGenericClass2 {
	public static void main(String[] args) {
		Test2<String, Integer> t2 = new Test2<>();
		t2.put("Sachin", 100);
	}
}

// Create a similar class like ArrayList - 
// Create a similar class like HashMap -