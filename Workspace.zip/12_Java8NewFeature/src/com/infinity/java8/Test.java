package com.infinity.java8;

interface NewFeature{
	public abstract void meth1(); // compulsory to override
	default public void meth2() { // not compulsory to override
		System.out.println("default Method-2 from interface");
		meth4();
	}
	public static void meth3() { // can't override static method
		System.out.println("static Method-3 from interface");
	}
	private void meth4() { // can't override static method
		System.out.println("private Method-4 from interface");
	}
}
class Impl implements NewFeature{
	@Override
	public void meth1() {
		System.out.println("meth1 of class Impl");
	}
}
//class Impl2 extends Impl{
//	
//}
public class Test {
	public static void main(String[] args) {
		NewFeature ref = new Impl();
		
		ref.meth1();
		ref.meth2();
		//ref.meth3(); // will give us compilation error
		NewFeature.meth3();
	}
}

