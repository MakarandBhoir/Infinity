package com.infinity.java8_02;

@FunctionalInterface
interface I1{
	void meth1();
}

// create class
// implement interface
// override the method
// define body
class Impl implements I1{
	@Override
	public void meth1() {
		System.out.println("meth1 of class Impl");
	}
}

public class Test {
	public static void main(String[] args) {
		I1 ref1 = new Impl();
		ref1.meth1();
		
		// Anonymous class - class which has no name
		// we don't have to create additional class
		// override the method
		// define the body
		I1 ref2 = new I1() {
			public void meth1() {
				System.out.println("meth1 of anonymous class");
			}
		};
		ref2.meth1();
		
		
		
	}
}
