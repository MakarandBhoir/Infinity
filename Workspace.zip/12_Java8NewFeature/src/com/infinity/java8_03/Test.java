package com.infinity.java8_03;

@FunctionalInterface
interface I1 {
	public int max(int num1, int num2);
}

public class Test {
	public static void main(String[] args) {

		I1 ref1 = (n1, n2) -> (n1 > n2) ? n1 : n2;

		System.out.println("Max = " + ref1.max(100, 200));

	}
}
