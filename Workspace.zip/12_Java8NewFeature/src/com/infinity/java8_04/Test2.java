package com.infinity.java8_04;

@FunctionalInterface
interface I2{
	public void print(String str);
}

public class Test2 {
	public static void main(String[] args) {
		I2 ref1 = (String str) -> {
			System.out.print(str);
		};
		ref1.print("Infinity");
		
		I2 ref2 = (str) -> System.out.print(" "+str);
		ref2.print("Classes");
		
		I2 ref3 = str -> System.out.println(" "+str);
		ref3.print("Uran");
	}
}
