package com.infinity.java8_07;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Test {
	public static void main(String[] args) {
		String com [] = {"Infosys", "JP Morgen", "HDFC", "HSBC", "CapGemini", "LNT", "Infinity"};
		
		List<String> list = Arrays.asList(com);
		
		System.out.println("Way 1 - to display list: ");
		System.out.println(list);
		
		// for each
		System.out.println("Way 2 - to display list: ");
		for(String str : list) {
			System.out.println(str);
		}
		// traditional for loop to display list
		// iterator to display list
		// list iterator to display list in reverse dir
		
		System.out.println("-----------------------------");
		Consumer<String> consumer = (String str) -> System.out.println(str);
		list.forEach(consumer);
		
		System.out.println("-------------------------------");
		list.forEach( str -> System.out.println(str) );
		
		System.out.println("---------------------------------");
		list.stream()
			.filter( e -> e.startsWith("I") )
			.forEach(e -> System.out.println(e));
	}
}
