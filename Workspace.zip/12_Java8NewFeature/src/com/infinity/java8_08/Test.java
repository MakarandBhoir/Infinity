package com.infinity.java8_08;

import java.util.function.BiConsumer;

public class Test {
	public static void main(String[] args) {
		BiConsumer<Integer, Double> consumer = (x, y) -> System.out.println("x: "+x+", y: "+y);
		consumer.accept(100, 10.5);
	}
}
