package stream01;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Test {
	public static void main(String[] args) {
		String comp[] = {"Infosys", "Tcs", "Capgemini", "JPMC", "Hdfc", "Hsbc", "Itc", "Infinity"};
		List<String> list = Arrays.asList(comp);
		
		Consumer<String> consumer = element-> System.out.println(element);
		list.forEach(consumer);
		
		
		//list.forEach( e -> System.out.println(e) );
	}
}
