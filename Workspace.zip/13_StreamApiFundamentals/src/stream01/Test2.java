package stream01;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Test2 {
	public static void main(String[] args) {
		String comp[] = { "Infosys", "Tcs", "Capgemini", "JPMC", "Hdfc", "Hsbc", "Itc", "Infinity" };
		List<String> list = Arrays.asList(comp);

		// list.forEach( e -> System.out.println(e) );
		Stream<String> stream = list.stream();
		//stream.forEach(e -> System.out.println(e)); // terminal operation
		
		//stream.forEach(e -> System.out.println(e)); // terminal operation
		
		stream = list.stream();
		Predicate<String> predicate = (String element) -> element.length() > 3;
		stream.filter(predicate)
		      .forEach(e -> System.out.println(e));
	}
}
